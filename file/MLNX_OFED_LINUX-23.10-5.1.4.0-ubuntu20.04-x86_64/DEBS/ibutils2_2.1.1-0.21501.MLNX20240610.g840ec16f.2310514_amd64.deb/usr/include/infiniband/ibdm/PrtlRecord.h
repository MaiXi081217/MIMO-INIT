/*
 * Copyright (c) 2023-2023 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 *
 * This software is available to you under the terms of the
 * OpenIB.org BSD license included below:
 *
 *     Redistribution and use in source and binary forms, with or
 *     without modification, are permitted provided that the following
 *     conditions are met:
 *
 *      - Redistributions of source code must retain the above
 *        copyright notice, this list of conditions and the following
 *        disclaimer.
 *
 *      - Redistributions in binary form must reproduce the above
 *        copyright notice, this list of conditions and the following
 *        disclaimer in the documentation and/or other materials
 *        provided with the distribution.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS
 * BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN
 * ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
 * CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */


#ifndef IBDM_PRTL_REC_H
#define IBDM_PRTL_REC_H

#include <string>
#include <ostream>
#include <map>
#include <string.h>

using namespace std;

struct PRTL_mod_dp_latency_key {
    PRTL_mod_dp_latency_key() {}

    bool operator< (const PRTL_mod_dp_latency_key& other) const {
        if (this == &other)   // Short?cut self?comparison
            return false;

        int ret = vendor_pn.compare(other.vendor_pn);
        if (ret < 0)
            return true;
        else if (ret > 0)
            return false;

        // All members are equal, so return false
        return false;;
   }

   string vendor_pn;
};

struct PRTL_phy_latency_key {
    bool operator< (const PRTL_phy_latency_key& other) const {
         return false;
    }
};

typedef std::map < PRTL_mod_dp_latency_key, u_int16_t > map_prtl_mod_dp_latency_t;
typedef std::map < PRTL_phy_latency_key, u_int16_t > map_prtl_phy_latency_t;

class PrtlRecord {
public:
    PrtlRecord();
    ~PrtlRecord() {}

    string CableLengthToStr(const PrtlRecord &remote) const;
    bool IsSupported() const { return (rtt_support ? true : false); }
    bool Validate(const PrtlRecord &remote, string &message) const;
    float CalculateLength(const PrtlRecord &remote) const;

    u_int8_t lp_msb;
    u_int8_t local_port;
    u_int8_t rtt_support;
    u_int8_t latency_accuracy;
    u_int8_t latency_res;
    u_int16_t local_phy_latency;
    u_int16_t local_mod_dp_latency;
    u_int32_t round_trip_latency;
};

#endif
